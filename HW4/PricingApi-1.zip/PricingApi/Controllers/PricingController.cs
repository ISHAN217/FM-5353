using PricingApi.Core;

using Microsoft.AspNetCore.Mvc;
using PricingApi.Models;

[ApiController]
[Route("api/pricing")]
public class PricingController : ControllerBase
{
    /// <summary>
    /// POST /api/pricing
    /// Body: PricingRequest JSON
    /// Returns: Price, SE, Greeks, echo input
    /// 
    /// Example JSON:
    /// {
    ///   "S0":100,"K":100,"r":0.03,"q":0.0,"sigma":0.2,"T":1.0,
    ///   "Steps":252,"NSamples":200000,
    ///   "VarianceReduction":3,      // Antithetic|DeltaControlVariate
    ///   "UseParallel":true, "BaseSeed":12345,
    ///   "PutCall":"Call",
    ///   "Style":"AsianArithmetic",
    ///   "Asian":{"AverageFromTimeZero":true},
    ///   "ComputeGreeks":true
    /// }
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<PricingResponse>> Price([FromBody] PricingRequest req)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);

        // Fail fast for unsupported styles
        if (req.Style == OptionStyle.American)
            return StatusCode(501, new { message = "American options not implemented in this wrapper (use LSM/trees)." });

        // Build payoff + CV
        IPathPayoff payoff;
        Func<double, double, double, double, double, double, double>? cvDelta;
        double kForCv; string note;
        try
        {
            (payoff, cvDelta, kForCv, note) = OptionFactory.Build(req);
        }
        catch (ArgumentException ex) { return BadRequest(new { message = ex.Message }); }
        catch (NotSupportedException ex) { return StatusCode(501, new { message = ex.Message }); }

        // Run pricing async so Kestrel thread isn't blocked (per lecture)
        var resp = await Task.Run(() =>
        {
            var pricer = new McPricer(req.UseParallel, req.MaxDegreeOfParallelism, req.BaseSeed);

            double price = pricer.Price(
                req.S0, req.r, req.q, req.sigma, req.T,
                req.Steps, req.NSamples, req.VarianceReduction,
                payoff, cvDelta, kForCv, out double se);

            Greeks? g = null;
            if (req.ComputeGreeks)
            {
                var gb = req.Bumps ?? new GreeksBumps();
                var greeks = pricer.Greeks(
                    req.S0, req.r, req.q, req.sigma, req.T,
                    req.Steps, req.NSamples, req.VarianceReduction,
                    payoff, cvDelta, kForCv,
                    dS: gb.dS, dSigma: gb.dSigma, dR: gb.dR, dT: gb.dT);

                g = new Greeks
                {
                    Delta = greeks.Delta,
                    Gamma = greeks.Gamma,
                    Vega  = greeks.Vega,
                    Rho   = greeks.Rho,
                    Theta = greeks.Theta
                };
            }

            return new PricingResponse
            {
                Price = price,
                StandardError = se,
                Greeks = g,
                Echo = req,
                Notes = $"{note}; MC with {(req.VarianceReduction.HasFlag(VarianceReduction.Antithetic) ? "antithetic, " : "")}" +
                        $"{(req.VarianceReduction.HasFlag(VarianceReduction.DeltaControlVariate) ? "delta-control-variates, " : "")}" +
                        $"{(req.UseParallel ? "parallel" : "single-thread")}."
            };
        });

        return Ok(resp);
    }

    [HttpGet("health")]
    public IActionResult Health() => Ok("pricing api up");
}
