using System;
using System.Collections.Concurrent;
using System.Threading.Tasks;

namespace PricingApi.Core
{
    internal struct RunningStats
    {
        public long Count;
        public double Mean;
        public double M2;

        public void Push(double x)
        {
            Count++;
            double delta = x - Mean;
            Mean += delta / Count;
            M2 += delta * (x - Mean);
        }

        public static RunningStats Merge(RunningStats a, RunningStats b)
        {
            if (a.Count == 0) return b;
            if (b.Count == 0) return a;

            long n = a.Count + b.Count;
            double delta = b.Mean - a.Mean;

            return new RunningStats
            {
                Count = n,
                Mean  = a.Mean + delta * (b.Count / (double)n),
                M2    = a.M2 + b.M2 + delta*delta * a.Count * b.Count / n
            };
        }
    }

    public sealed class McPricer
    {
        private readonly bool _useParallel;
        private readonly int _maxDegree;
        private readonly int _baseSeed;

        public McPricer(bool useParallel = false, int? maxDegreeOfParallelism = null, int baseSeed = 12345)
        {
            _useParallel = useParallel;
            _maxDegree = (maxDegreeOfParallelism.HasValue && maxDegreeOfParallelism.Value > 0)
                ? maxDegreeOfParallelism.Value
                : Environment.ProcessorCount;
            _baseSeed = baseSeed;
        }

        private static void ValidateInputs(double S0, double r, double q, double sigma, double T, int steps, int nSamples, IPathPayoff payoff)
        {
            if (S0 <= 0) throw new ArgumentOutOfRangeException(nameof(S0));
            if (sigma < 0) throw new ArgumentOutOfRangeException(nameof(sigma));
            if (T <= 0) throw new ArgumentOutOfRangeException(nameof(T));
            if (steps <= 0) throw new ArgumentOutOfRangeException(nameof(steps));
            if (nSamples <= 0) throw new ArgumentOutOfRangeException(nameof(nSamples));
            if (payoff is null) throw new ArgumentNullException(nameof(payoff));
        }

        public double Price(
            double S0, double r, double q, double sigma, double T,
            int steps, int nSamples, VarianceReduction vr,
            IPathPayoff payoff,
            Func<double,double,double,double,double,double,double>? payoffDeltaForCV,
            double KforCV,
            out double stdError)
        {
            ValidateInputs(S0, r, q, sigma, T, steps, nSamples, payoff);

            bool useAnti = vr.HasFlag(VarianceReduction.Antithetic);
            bool useCv   = vr.HasFlag(VarianceReduction.DeltaControlVariate);

            if (useAnti && (nSamples % 2 != 0))
                throw new ArgumentException("nSamples must be even when Antithetic is enabled.");

            int nUnits = useAnti ? nSamples / 2 : nSamples; // each unit => one averaged observation
            double dt = T / steps;
            double disc = Math.Exp(-r * T);

            if (!_useParallel || nUnits <= 1)
            {
                var gen = new GbmExactPathGen(seed: _baseSeed, antithetic: useAnti);
                double mean = 0.0, m2 = 0.0; int k = 0;
                for (int n = 0; n < nUnits; n++)
                {
                    var (p, a) = gen.Generate(S0, r, q, sigma, dt, steps);
                    double y1 = payoff.Payoff(p);
                    if (useCv && payoffDeltaForCV != null)
                        y1 -= DeltaCv.HedgingControlVariate(p, r, q, dt, payoffDeltaForCV, KforCV, sigma, T);

                    double y = y1;
                    if (useAnti && a != null)
                    {
                        double y2 = payoff.Payoff(a);
                        if (useCv && payoffDeltaForCV != null)
                            y2 -= DeltaCv.HedgingControlVariate(a, r, q, dt, payoffDeltaForCV, KforCV, sigma, T);
                        y = 0.5 * (y1 + y2);
                    }

                    k++;
                    double d = y - mean;
                    mean += d / k;
                    m2 += d * (y - mean);
                }
                double var = k > 1 ? m2 / (k - 1) : 0.0;
                stdError = disc * Math.Sqrt(var / Math.Max(k,1));
                return disc * mean;
            }
            else
            {
                var range = Partitioner.Create(0, nUnits, Math.Max(1, nUnits / (_maxDegree * 4)));
                var po = new ParallelOptions { MaxDegreeOfParallelism = _maxDegree };

                RunningStats global = default; object gate = new object();

                Parallel.ForEach(range, po, () => default(RunningStats), (slice, _, local) =>
                {
                    // per-slice RNG seed shift prevents correlation across threads
                    for (int n = slice.Item1; n < slice.Item2; n++)
                    {
                        var gen = new GbmExactPathGen(seed: _baseSeed + n, antithetic: useAnti);
                        var (p, a) = gen.Generate(S0, r, q, sigma, dt, steps);

                        double y1 = payoff.Payoff(p);
                        if (useCv && payoffDeltaForCV != null)
                            y1 -= DeltaCv.HedgingControlVariate(p, r, q, dt, payoffDeltaForCV, KforCV, sigma, T);

                        double y = y1;
                        if (useAnti && a != null)
                        {
                            double y2 = payoff.Payoff(a);
                            if (useCv && payoffDeltaForCV != null)
                                y2 -= DeltaCv.HedgingControlVariate(a, r, q, dt, payoffDeltaForCV, KforCV, sigma, T);
                            y = 0.5 * (y1 + y2);
                        }
                        local.Push(y);
                    }
                    return local;
                },
                local => { lock (gate) { global = RunningStats.Merge(global, local); } });

                long kTot = global.Count;
                double varTot = kTot > 1 ? global.M2 / (kTot - 1) : 0.0;
                stdError = disc * Math.Sqrt(varTot / Math.Max(kTot,1));
                return disc * global.Mean;
            }
        }

        // Greeks via CRN bump-and-revalue (central diffs)
        public (double Delta, double Gamma, double Vega, double Rho, double Theta) Greeks(
            double S0, double r, double q, double sigma, double T,
            int steps, int nSamples, VarianceReduction vr,
            IPathPayoff payoff,
            Func<double,double,double,double,double,double,double>? payoffDeltaForCV,
            double KforCV,
            double dS = 1e-2, double dSigma = 1e-4, double dR = 1e-4, double dT = 1.0/365.0)
        {
            // central differences with CRN via baseSeed reuse
            double P0 = Price(S0, r, q, sigma, T, steps, nSamples, vr, payoff, payoffDeltaForCV, KforCV, out _);

            double PSu = new McPricer(_useParallel, _maxDegree, _baseSeed).Price(S0 + dS, r, q, sigma, T, steps, nSamples, vr, payoff, payoffDeltaForCV, KforCV, out _);
            double PSd = new McPricer(_useParallel, _maxDegree, _baseSeed).Price(Math.Max(S0 - dS, 1e-8), r, q, sigma, T, steps, nSamples, vr, payoff, payoffDeltaForCV, KforCV, out _);

            double PVu = new McPricer(_useParallel, _maxDegree, _baseSeed).Price(S0, r, q, sigma + dSigma, T, steps, nSamples, vr, payoff, payoffDeltaForCV, KforCV, out _);
            double PVd = new McPricer(_useParallel, _maxDegree, _baseSeed).Price(S0, r, q, Math.Max(sigma - dSigma, 1e-8), T, steps, nSamples, vr, payoff, payoffDeltaForCV, KforCV, out _);

            double PRu = new McPricer(_useParallel, _maxDegree, _baseSeed).Price(S0, r + dR, q, sigma, T, steps, nSamples, vr, payoff, payoffDeltaForCV, KforCV, out _);
            double PRd = new McPricer(_useParallel, _maxDegree, _baseSeed).Price(S0, Math.Max(r - dR, -1.0), q, sigma, T, steps, nSamples, vr, payoff, payoffDeltaForCV, KforCV, out _);

            double PTu = new McPricer(_useParallel, _maxDegree, _baseSeed).Price(S0, r, q, sigma, Math.Max(T + dT, 1e-9), steps, nSamples, vr, payoff, payoffDeltaForCV, KforCV, out _);
            double PTd = new McPricer(_useParallel, _maxDegree, _baseSeed).Price(S0, r, q, sigma, Math.Max(T - dT, 1e-9), steps, nSamples, vr, payoff, payoffDeltaForCV, KforCV, out _);

            double delta = (PSu - PSd) / (2.0 * dS);
            double gamma = (PSu - 2.0*P0 + PSd) / (dS*dS);
            double vega  = (PVu - PVd) / (2.0 * dSigma);
            double rho   = (PRu - PRd) / (2.0 * dR);
            double theta = (PTd - PTu) / (2.0 * dT); // dPrice/dT (usually negative)

            return (delta, gamma, vega, rho, theta);
        }
    }
}
