using System;

namespace PricingApi.Core
{
    public static class Normal
    {
        // Abramowitz–Stegun 7.1.26
        public static double Erf(double x)
        {
            const double a1=0.254829592, a2=-0.284496736, a3=1.421413741,
                         a4=-1.453152027, a5=1.061405429, p=0.3275911;
            int sign = x < 0 ? -1 : 1;
            x = Math.Abs(x);
            double t = 1.0/(1.0+p*x);
            double y = 1.0 - (((((a5*t + a4)*t + a3)*t + a2)*t + a1)*t) * Math.Exp(-x*x);
            return sign * y;
        }

        public static double Cdf(double x) => 0.5 * (1.0 + Erf(x / Math.Sqrt(2.0)));
        public static double Pdf(double x) => Math.Exp(-0.5*x*x) / Math.Sqrt(2.0*Math.PI);
    }

    public static class BlackScholes
    {
        // Numerically stable log division
        private static double SafeLogDiv(double a, double b)
        {
            if (a <= 0 || b <= 0) throw new ArgumentOutOfRangeException(nameof(a), "S and K must be > 0");
            return Math.Log(a) - Math.Log(b);
        }

        public static double D1(double S, double K, double r, double q, double sigma, double T)
        {
            if (sigma <= 0 || T <= 0) throw new ArgumentOutOfRangeException("sigma/T must be > 0");
            double v = sigma * Math.Sqrt(T);
            double m = SafeLogDiv(S, K) + (r - q + 0.5*sigma*sigma) * T;
            return m / v;
        }

        public static double PriceCall(double S, double K, double r, double q, double sigma, double T)
        {
            double d1 = D1(S,K,r,q,sigma,T);
            double d2 = d1 - sigma*Math.Sqrt(T);
            return S*Math.Exp(-q*T)*Normal.Cdf(d1) - K*Math.Exp(-r*T)*Normal.Cdf(d2);
        }

        public static double PricePut(double S, double K, double r, double q, double sigma, double T)
        {
            double d1 = D1(S,K,r,q,sigma,T);
            double d2 = d1 - sigma*Math.Sqrt(T);
            return K*Math.Exp(-r*T)*Normal.Cdf(-d2) - S*Math.Exp(-q*T)*Normal.Cdf(-d1);
        }

        public static double CallDelta(double S, double K, double r, double q, double sigma, double T)
        {
            double d1 = D1(S,K,r,q,sigma,T);
            return Math.Exp(-q*T) * Normal.Cdf(d1);
        }

        public static double PutDelta(double S, double K, double r, double q, double sigma, double T)
        {
            double d1 = D1(S,K,r,q,sigma,T);
            return Math.Exp(-q*T) * (Normal.Cdf(d1) - 1.0);
        }
    }
}
