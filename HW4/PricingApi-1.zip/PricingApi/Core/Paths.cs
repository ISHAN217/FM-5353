using System;

namespace PricingApi.Core
{
    public interface IPathGen
    {
        // Returns primary path and optional antithetic path of length (steps+1)
        (double[] path, double[]? antiPath) Generate(double S0, double r, double q, double sigma, double dt, int steps);
    }

    public sealed class GbmExactPathGen : IPathGen
    {
        private readonly Random _rng;
        private readonly bool _antithetic;

        public GbmExactPathGen(int seed, bool antithetic = false)
        {
            _rng = new Random(seed);
            _antithetic = antithetic;
        }

        public (double[] path, double[]? antiPath) Generate(double S0, double r, double q, double sigma, double dt, int steps)
        {
            if (S0 <= 0) throw new ArgumentOutOfRangeException(nameof(S0));
            if (sigma < 0) throw new ArgumentOutOfRangeException(nameof(sigma));
            if (dt <= 0 || steps <= 0) throw new ArgumentOutOfRangeException(nameof(steps));

            double drift = (r - q - 0.5*sigma*sigma) * dt;
            double vol   = sigma * Math.Sqrt(dt);

            var p = new double[steps + 1]; p[0] = S0;
            double[]? a = _antithetic ? new double[steps + 1] : null;
            if (a != null) a[0] = S0;

            for (int i = 0; i < steps; i++)
            {
                double z = StdNormal();
                p[i+1] = p[i] * Math.Exp(drift + vol*z);
                if (a != null) a[i+1] = a[i] * Math.Exp(drift - vol*z);
            }
            return (p, a);

            double StdNormal()
            {
                // Box–Muller with basic protections
                double u1 = 1.0 - _rng.NextDouble();
                double u2 = 1.0 - _rng.NextDouble();
                u1 = Math.Max(u1, double.Epsilon);
                return Math.Sqrt(-2.0*Math.Log(u1)) * Math.Cos(2.0*Math.PI*u2);
            }
        }
    }
}
