using System;

namespace PricingApi.Core
{
    public static class DeltaCv
    {
        /// <summary>
        /// Discrete-time self-financing delta hedge CV:
        /// subtract sum_t Delta(S_t, tau_t) * (S_{t+1} - E[S_{t+1}|S_t])
        /// where E[S_{t+1}|S_t] = S_t * exp((r - q) * dt) under risk-neutral GBM.
        /// </summary>
        public static double HedgingControlVariate(
            double[] path, double r, double q, double dt,
            Func<double,double,double,double,double,double,double> payoffDelta,
            double K, double sigma, double T)
        {
            int m = path.Length - 1;
            if (m <= 0) return 0.0;

            double adj = 0.0;
            double driftFactor = Math.Exp((r - q) * dt);

            // tau_t = time to maturity from t
            for (int i = 0; i < m; i++)
            {
                double t   = i * dt;
                double tau = Math.Max(T - t, 1e-12);
                double Si  = path[i];
                double Si1 = path[i + 1];

                double delta = payoffDelta(Si, K, r, q, sigma, tau);
                // CV term is the PnL of delta hedge against risk-neutral drift
                adj += delta * (Si1 - driftFactor * Si);
            }
            return adj;
        }
    }
}
