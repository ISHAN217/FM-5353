namespace PricingApi.Core
{
    [System.Flags]
    public enum VarianceReduction
    {
        None                 = 0,
        Antithetic           = 1 << 0,
        DeltaControlVariate  = 1 << 1
    }

    public enum BarrierType
    {
        UpAndOut,
        DownAndOut,
        UpAndIn,
        DownAndIn
    }

    public enum LookbackType
    {
        FixedStrike,
        FloatingStrike
    }
}
