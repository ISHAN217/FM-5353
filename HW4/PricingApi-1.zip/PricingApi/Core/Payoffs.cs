using System;

namespace PricingApi.Core
{
    public interface IPathPayoff
    {
        double Payoff(double[] path);
    }

    public sealed class EuropeanCall : IPathPayoff
    {
        private readonly double _K;
        public EuropeanCall(double K) { if (K <= 0) throw new ArgumentOutOfRangeException(nameof(K)); _K = K; }
        public double Payoff(double[] path) => Math.Max(path[^1] - _K, 0.0);
    }

    public sealed class EuropeanPut : IPathPayoff
    {
        private readonly double _K;
        public EuropeanPut(double K) { if (K <= 0) throw new ArgumentOutOfRangeException(nameof(K)); _K = K; }
        public double Payoff(double[] path) => Math.Max(_K - path[^1], 0.0);
    }

    public sealed class AsianArithmetic : IPathPayoff
    {
        private readonly double _K; private readonly bool _isCall; private readonly bool _avgFromZero;
        public AsianArithmetic(double K, bool isCall = true, bool useAveragingFromTimeZero = true)
        {
            if (K < 0) throw new ArgumentOutOfRangeException(nameof(K));
            _K = K; _isCall = isCall; _avgFromZero = useAveragingFromTimeZero;
        }

        public double Payoff(double[] path)
        {
            int start = _avgFromZero ? 0 : 1;
            if (start >= path.Length) start = 0;
            double sum = 0.0; int n = 0;
            for (int i = start; i < path.Length; i++) { sum += path[i]; n++; }
            double avg = sum / Math.Max(n, 1);
            return _isCall ? Math.Max(avg - _K, 0.0) : Math.Max(_K - avg, 0.0);
        }
    }

    public sealed class DigitalOption : IPathPayoff
    {
        private readonly double _K; private readonly bool _isCall; private readonly double _cash;
        public DigitalOption(double K, bool isCall = true, double cashPayout = 1.0)
        {
            if (K <= 0) throw new ArgumentOutOfRangeException(nameof(K));
            if (cashPayout < 0) throw new ArgumentOutOfRangeException(nameof(cashPayout));
            _K = K; _isCall = isCall; _cash = cashPayout;
        }
        public double Payoff(double[] path)
        {
            double ST = path[^1];
            bool hit = _isCall ? (ST > _K) : (ST < _K);
            return hit ? _cash : 0.0;
        }
    }

    public sealed class BarrierOption : IPathPayoff
    {
        private readonly double _K; private readonly bool _isCall;
        private readonly BarrierType _type; private readonly double _barrier; private readonly double _rebate;

        public BarrierOption(double K, bool isCall, BarrierType type, double barrier, double rebate = 0.0)
        {
            if (K <= 0) throw new ArgumentOutOfRangeException(nameof(K));
            if (barrier <= 0) throw new ArgumentOutOfRangeException(nameof(barrier));
            if (rebate < 0) throw new ArgumentOutOfRangeException(nameof(rebate));
            _K = K; _isCall = isCall; _type = type; _barrier = barrier; _rebate = rebate;
        }

        public double Payoff(double[] path)
        {
            bool touched = false;
            for (int i = 0; i < path.Length; i++)
            {
                double S = path[i];
                if ((_type == BarrierType.UpAndOut || _type == BarrierType.UpAndIn) && S >= _barrier) { touched = true; break; }
                if ((_type == BarrierType.DownAndOut || _type == BarrierType.DownAndIn) && S <= _barrier) { touched = true; break; }
            }

            double ST = path[^1];
            double intrinsic = _isCall ? Math.Max(ST - _K, 0.0) : Math.Max(_K - ST, 0.0);

            return _type switch
            {
                BarrierType.UpAndOut or BarrierType.DownAndOut => touched ? _rebate : intrinsic,
                BarrierType.UpAndIn  or BarrierType.DownAndIn  => touched ? intrinsic : _rebate,
                _ => 0.0
            };
        }
    }

    public sealed class LookbackOption : IPathPayoff
    {
        private readonly bool _isCall; private readonly LookbackType _type; private readonly double _K;
        public LookbackOption(bool isCall, LookbackType type, double K = 0.0)
        {
            if (type == LookbackType.FixedStrike && K < 0) throw new ArgumentOutOfRangeException(nameof(K));
            _isCall = isCall; _type = type; _K = K;
        }

        public double Payoff(double[] path)
        {
            double sMin = double.MaxValue, sMax = double.MinValue;
            foreach (var s in path) { if (s < sMin) sMin = s; if (s > sMax) sMax = s; }
            double ST = path[^1];

            return _type == LookbackType.FloatingStrike
                ? (_isCall ? Math.Max(ST - sMin, 0.0) : Math.Max(sMax - ST, 0.0))
                : (_isCall ? Math.Max(sMax - _K, 0.0) : Math.Max(_K - sMin, 0.0));
        }
    }

    public sealed class RangeOption : IPathPayoff
    {
        private readonly double _K;
        public RangeOption(double K = 0.0) { if (K < 0) throw new ArgumentOutOfRangeException(nameof(K)); _K = K; }

        public double Payoff(double[] path)
        {
            double sMin = double.MaxValue, sMax = double.MinValue;
            foreach (var s in path) { if (s < sMin) sMin = s; if (s > sMax) sMax = s; }
            return Math.Max((sMax - sMin) - _K, 0.0);
        }
    }
}
