using PricingApi.Core;

using System;
using PricingApi.Models;

// NOTE: This factory uses our existing payoff classes from the previous week's assignment:
//   EuropeanCall, EuropeanPut, AsianArithmetic, DigitalOption,
//   BarrierOption, LookbackOption, RangeOption,
// and the VarianceReduction enum, BarrierType, LookbackType,
// plus BlackScholes.CallDelta/PutDelta for control variate delta.
public static class OptionFactory
{
    public static (IPathPayoff payoff,
                   Func<double,double,double,double,double,double,double>? cvDelta,
                   double kForCv,
                   string note) Build(PricingRequest req)
    {
        bool isCall = req.PutCall == PutCall.Call;
        IPathPayoff payoff;
        string note = "";

        switch (req.Style)
        {
            case OptionStyle.European:
                payoff = isCall ? new EuropeanCall(req.K) : new EuropeanPut(req.K);
                note = "European terminal payoff";
                break;

            case OptionStyle.AsianArithmetic:
                var avgFromZero = req.Asian?.AverageFromTimeZero ?? true;
                payoff = new AsianArithmetic(req.K, isCall: isCall, useAveragingFromTimeZero: avgFromZero);
                note = "Arithmetic Asian average payoff";
                break;

            case OptionStyle.Digital:
                payoff = new DigitalOption(req.K, isCall: isCall, cashPayout: 1.0);
                note = "Cash-or-nothing digital";
                break;

            case OptionStyle.Barrier:
                if (req.Barrier is null)
                    throw new ArgumentException("Barrier parameters are required for Barrier style.");
                payoff = new BarrierOption(req.K, isCall, req.Barrier.Type, req.Barrier.Barrier, req.Barrier.Rebate);
                note = $"Barrier {req.Barrier.Type} (B={req.Barrier.Barrier}, rebate={req.Barrier.Rebate})";
                break;

            case OptionStyle.Lookback:
                if (req.Lookback is null)
                    throw new ArgumentException("Lookback parameters are required for Lookback style.");
                payoff = new LookbackOption(isCall, req.Lookback.Type, req.Lookback.K);
                note = $"Lookback {req.Lookback.Type}";
                break;

            case OptionStyle.Range:
                double kRange = req.Range?.K ?? 0.0;
                payoff = new RangeOption(kRange);
                note = $"Range (K={kRange})";
                break;

            case OptionStyle.American:
                throw new NotSupportedException("American (early exercise) not implemented in this MC wrapper (LSM etc. required).");

            default:
                throw new ArgumentOutOfRangeException(nameof(req.Style));
        }

        // Control variate delta: use European deltas as a generic hedge CV when enabled
        Func<double,double,double,double,double,double,double>? cvDelta = null;
        if (req.VarianceReduction.HasFlag(VarianceReduction.DeltaControlVariate))
        {
            cvDelta = isCall
                ? (S, K, r, q, sig, tau) => BlackScholes.CallDelta(S, K, r, q, sig, tau)
                : (S, K, r, q, sig, tau) => BlackScholes.PutDelta (S, K, r, q, sig, tau);
        }

        return (payoff, cvDelta, req.K, note);
    }
}
