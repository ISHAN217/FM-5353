using PricingApi.Core;

using System.ComponentModel.DataAnnotations;

namespace PricingApi.Models
{
    public enum OptionStyle
    {
        European,
        AsianArithmetic,
        Digital,
        Barrier,
        Lookback,
        Range,
        American // not implemented in this wrapper
    }

    public enum PutCall { Call, Put }

    public sealed class BarrierParams
    {
        [Required] public BarrierType Type { get; set; }
        [Required] public double Barrier { get; set; }
        public double Rebate { get; set; } = 0.0;
    }

    public sealed class LookbackParams
    {
        [Required] public LookbackType Type { get; set; } = LookbackType.FloatingStrike;
        public double K { get; set; } = 0.0; // used for fixed-strike
    }

    public sealed class AsianParams
    {
        public bool AverageFromTimeZero { get; set; } = true;
    }

    public sealed class RangeParams
    {
        public double K { get; set; } = 0.0; // 0 => pure range
    }

    public sealed class GreeksBumps
    {
        public double dS { get; set; } = 1e-2;
        public double dSigma { get; set; } = 1e-4;
        public double dR { get; set; } = 1e-4;
        public double dT { get; set; } = 1.0 / 365.0;
    }

    public sealed class PricingRequest
    {
        // Market & contract
        [Range(0, double.MaxValue)] public double S0 { get; set; }
        [Range(0, double.MaxValue)] public double K { get; set; }
        public PutCall PutCall { get; set; } = PutCall.Call;
        public double r { get; set; }
        public double q { get; set; } = 0.0;
        [Range(0, double.MaxValue)] public double sigma { get; set; }
        [Range(0, double.MaxValue)] public double T { get; set; }

        // MC controls
        [Range(2, int.MaxValue)] public int Steps { get; set; } = 252;
        [Range(100, int.MaxValue)] public int NSamples { get; set; } = 200_000;
        public VarianceReduction VarianceReduction { get; set; } =
            VarianceReduction.Antithetic | VarianceReduction.DeltaControlVariate;

        // Parallelization
        public bool UseParallel { get; set; } = true;
        public int? MaxDegreeOfParallelism { get; set; } = null;
        public int BaseSeed { get; set; } = 12345;

        // What to compute
        public bool ComputeGreeks { get; set; } = true;
        public GreeksBumps Bumps { get; set; } = new();

        // Style switches
        [Required] public OptionStyle Style { get; set; } = OptionStyle.AsianArithmetic;
        public AsianParams? Asian { get; set; }
        public BarrierParams? Barrier { get; set; }
        public LookbackParams? Lookback { get; set; }
        public RangeParams? Range { get; set; }
    }

    public sealed class Greeks
    {
        public double Delta { get; set; }
        public double Gamma { get; set; }
        public double Vega { get; set; }
        public double Rho { get; set; }
        public double Theta { get; set; }
    }

    public sealed class PricingResponse
    {
        public double Price { get; set; }
        public double StandardError { get; set; }
        public Greeks? Greeks { get; set; }
        public string Notes { get; set; } = "";
        public PricingRequest Echo { get; set; } = default!;
    }
}
